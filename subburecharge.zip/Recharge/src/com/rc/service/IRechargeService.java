package com.rc.service;

import java.sql.SQLException;

import com.rc.bean.RechargeBean;
import com.rc.exception.RechargeException;

public interface IRechargeService {
	public abstract int validateInput(RechargeBean recharge);
	public abstract int doRecharge(RechargeBean rbobj) throws RechargeException, SQLException;
	public abstract void validateRecharge(RechargeBean robj);

}
