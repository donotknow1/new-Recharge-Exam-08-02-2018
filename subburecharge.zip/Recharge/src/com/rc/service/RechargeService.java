package com.rc.service;

import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.rc.bean.RechargeBean;
import com.rc.dao.IRechargeDao;
import com.rc.dao.RechargeDao;
import com.rc.exception.RechargeException;

public class RechargeService implements IRechargeService {
	IRechargeDao rdao=null;
	@Override
	public int validateInput(RechargeBean robj) {
		String name = robj.getName();
		String mno = robj.getMobile();
		String amount= robj.getAmount();
		
		boolean nameResult = validateName(name);
		boolean mnoResult = validateMno(mno);
		boolean amtResult = validateAmt(amount);
		if (nameResult==true && mnoResult==true && amtResult==true) {
			System.out.println("All the data is validated");
			return 1;
		}
		else {
			System.out.println("Please Reenter the Data");
		return 0;
		}
		}
		

	private boolean validateAmt(String amount) {
		Pattern pamt = Pattern.compile("\\d{3}");
		Matcher mamt = pamt.matcher(amount);
		if (mamt.matches()) {
			System.out.println("Amount Validated "+amount);
			return true;
		}
		else {
			System.out.println("Amount is not matching: "+amount);
			return false;
		}
		
	}


	private boolean validateMno(String mno) {
		Pattern pmno =Pattern.compile("\\d{10}");
		Matcher mmno = pmno.matcher(mno);
		if (mmno.matches()) {
			System.out.println("Phone Number is Valid: "+mno);
			return true;
		}
		else {
			System.out.println("Phone Number is not matching: "+mno);
		}
		return false;
	
	}


	private boolean validateName(String name) {
		Pattern pname = Pattern.compile("[A-Z][a-z][a-z][a-z]");
		Matcher mname = pname.matcher(name);
		if (mname.matches()) {
			System.out.println("Name Matches: "+name);
			return true;
		}
		else {
			System.out.println("Name is not matching: "+name);
			return false;
		}
		
	}
	


	@Override
	public int doRecharge(RechargeBean robj) throws RechargeException, SQLException {
		rdao = new RechargeDao();
		return rdao.doRecharge(robj);
		
		
	}

	 public void validateRecharge(RechargeBean robj) {
		 System.out.println("validate");
		 System.out.println("amount"+robj.getAmount());
		 if(robj.getAmount().equals("99")) {
			 robj.setPlannama("Rc99");
			 robj.setStatus("Recharge Successfull");
		 }else if(robj.getAmount().equals("199")) {
			 robj.setPlannama("Rc199");
			 robj.setStatus("Recharge Successfull"); 
		 }else if(robj.getAmount().equals("299")) {
			 robj.setPlannama("Rc299");
			 robj.setStatus("Recharge Successfull"); 
		 }
		 else {
			 System.out.println("plan not available");
		 }
		 
		 
		 
		
		 
		 
		 
	 }
	
}
