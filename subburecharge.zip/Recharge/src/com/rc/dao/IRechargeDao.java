package com.rc.dao;

import java.sql.SQLException;

import com.rc.bean.RechargeBean;
import com.rc.exception.RechargeException;

public interface IRechargeDao {

	int doRecharge(RechargeBean robj) throws RechargeException, SQLException;



}
