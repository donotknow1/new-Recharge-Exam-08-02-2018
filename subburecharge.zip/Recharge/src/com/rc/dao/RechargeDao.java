package com.rc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.rc.bean.RechargeBean;
import com.rc.exception.RechargeException;
import com.rc.util.DbUtil;


public class RechargeDao implements IRechargeDao {
	Connection conn= null;
	@Override
	public int doRecharge(RechargeBean robj) throws RechargeException, SQLException {
		
		int status=0;
		System.out.println("Connecting");
		conn=DbUtil.getDbConnection();
		System.out.println("Connected");
		try {
			conn.setAutoCommit(true);
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.DO_RECHARGE_QRY);
			System.out.println("Query Compiled");
			pst.setString(1, robj.getName());
			pst.setString(2, robj.getMobile());
			pst.setString(3, robj.getAmount());
			pst.setString(4, robj.getPlannama());
			pst.setString(5, robj.getStatus());
			System.out.println("Query is Updating");
			status = pst.executeUpdate();
			System.out.println("Connected");
			System.out.println("Status is: "+status);
		}
		catch (SQLException e) {
			//throw new RechargeException("data not stored "+e.getMessage());
		}
		
		return status;
		
	}

}
