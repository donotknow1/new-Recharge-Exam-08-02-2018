package com.rc.dao;

public interface IQueryMapper {
public static final String DO_RECHARGE_QRY="INSERT INTO  RECHARGE3 VAlUES(seq_rech.NEXTVAL,?,?,?,?,sysdate,?)";
}
