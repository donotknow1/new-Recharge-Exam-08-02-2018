package com.rc.exception;

public class RechargeException extends Exception {
	public String RechargeException(String msg){
		
		return msg;
	}
}
