package com.rc.bean;

public class RechargeBean {
	
	private int rechargeid;
	private String name;
	private String mobile;
	private String amount;
	private String plannama;
	private String date;
	private String status;
	
	
	
	public int getRechargeid() {
		return rechargeid;
	}
	public void setRechargeid(int rechargeid) {
		this.rechargeid = rechargeid;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getPlannama() {
		return plannama;
	}
	public void setPlannama(String plannama) {
		this.plannama = plannama;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public RechargeBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public RechargeBean(int rechargeid, String name, String mobile, String amount, String plannama, String date,
			String status) {
		super();
		this.rechargeid = rechargeid;
		this.name = name;
		this.mobile = mobile;
		this.amount = amount;
		this.plannama = plannama;
		this.date = date;
		this.status = status;
		
	}
	public RechargeBean(String name, String mno, String amount) {
		super();
		this.name = name;
		this.mobile = mno;
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "RechargeBean [rechargeid=" + rechargeid + ", name=" + name + ", mobile=" + mobile + ", amount=" + amount
				+ ", plannama=" + plannama + ", date=" + date + ", status=" + status + "]";
	}
	

}
