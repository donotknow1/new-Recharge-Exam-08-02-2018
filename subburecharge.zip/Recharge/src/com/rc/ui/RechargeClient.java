package com.rc.ui;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

import com.rc.bean.RechargeBean;
import com.rc.exception.RechargeException;
import com.rc.service.IRechargeService;
import com.rc.service.RechargeService;

public class RechargeClient {
	static Scanner scobj=null;
	static IRechargeService irsobj = null;
	
	static Connection conn=null;
	static RechargeBean robj=null;
	
	public static void main(String[] args) throws RechargeException, SQLException {
	//	conn = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl","trg224", "training224");
		robj=new RechargeBean();
		
		System.out.println("===Recharge management system===");
		System.out.println("--------------------------------");
		System.out.println("1. To Recharge");
		System.out.println("2. update");
		System.out.println("3. exit");
		System.out.println("--------------------------------");
		System.out.println("Enter your option");
		scobj = new Scanner(System.in);
		int option = scobj.nextInt(); 
		
		switch(option) {
		case 1:
			 irsobj=new RechargeService();
			System.out.println("Enter your Name: ");
			String name = scobj.next();
			robj.setName(name);
			System.out.println("Enter your Mobile Number to recharge:");
			String mno = scobj.next();
			robj.setMobile(mno);
			System.out.println("Enter your Recahrge Amount: ");
			String amount = scobj.next();
			robj.setAmount(amount);
			irsobj.validateRecharge(robj);
			System.out.println(robj.getAmount());
			
			//RechargeBean robj = new RechargeBean(name, mno, amount);	
			int val= 0;
			int result = 0;
			try {
				val = validateInput(robj);
				System.out.println("For recharing VAL is: "+val);
				if (val>0) {
					result = doRecharge(robj);
					System.out.println("Result is: "+result);
					
				}
			}
				catch(Exception e) {
					
		}
	}				
}

	private static int validateInput(RechargeBean robj) {
		irsobj = new RechargeService();
		int valResult = irsobj.validateInput(robj);
		if (valResult==1) {
			return 1;
		}
		else {
			return 0;
		}
	}

	private static int doRecharge(RechargeBean robj) throws RechargeException, SQLException {
		irsobj= new RechargeService();
		int rechargeResult = irsobj.doRecharge(robj);
		return rechargeResult;
		
	}
}
