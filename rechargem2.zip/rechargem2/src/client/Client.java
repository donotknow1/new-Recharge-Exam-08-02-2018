package client;

import java.sql.SQLException;
import java.util.Scanner;

import bean.RechargeBean;
import service.IService;
import service.Service;

public class Client {
	static Scanner sc=null;
	static int res=0;
	static int res1=0;
	static IService ser=null;
public static void main(String[] args) throws SQLException {
	sc=new Scanner(System.in);
	ser=new Service();
	System.out.println("***RECHARGE***");
	System.out.println("enter name");
	String name=sc.next();
	System.out.println("enter mobile number");
	String number=sc.next();
	System.out.println("enter amount");
	int amount=sc.nextInt();
	
	String plantype= ser.validate(amount);
	RechargeBean b1=new RechargeBean(name,number,amount,plantype);
	
	try {
		res=addDetails(b1);
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	if(res>0) {
		System.out.println("recharged successfully");
		//res1=addFinalDetails(b1);*/
	}
		else {
			System.out.println("try again");
		}
	}
/*private static int addFinalDetails(RechargeBean b1) throws SQLException {
	// TODO Auto-generated method stub
	ser=new Service();
	return ser.addFinalDetails(b1);
}*/
private static int addDetails(RechargeBean b1) throws SQLException {
	// TODO Auto-generated method stub
	ser=new Service();
	return ser.addDetails(b1);
}
}