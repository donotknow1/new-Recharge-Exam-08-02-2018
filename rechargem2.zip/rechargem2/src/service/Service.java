package service;

import java.sql.SQLException;

import bean.RechargeBean;
import dao.IRecDao;
import dao.RecDao;

public class Service implements IService {
IRecDao dao=null;
String plan=null;
	@Override
	public int addDetails(RechargeBean b1) throws SQLException {
		// TODO Auto-generated method stub
		dao=new RecDao();
	return 	dao.addDetails(b1);
	
}
	@Override
	public String validate(int amount) {
		// TODO Auto-generated method stub
		if(amount==99) {
			
			plan = "Rs99"	;
				}
				else if(amount==199){
			 plan="Rs199";
				}
				else if(amount==299) {
				 plan="Rc299";
				}
				else {
					System.out.println("no plan found");
				}
			return plan;
	}
	/*@Override
	public int addFinalDetails(RechargeBean b1) throws SQLException {
		// TODO Auto-generated method stub
		dao=new RecDao();
		return 	dao.addFianlDetails(b1);

	}*/
}










