package dao;

public interface IQueryMapper {

	String rec_insert_qry = "insert into rec values(se1.nextval,?,?,?,?,sysdate)";
	String rec_insert_qry1 = "insert into rec values(se1.nextval,?,?,?,?,sysdate,?)";

}
