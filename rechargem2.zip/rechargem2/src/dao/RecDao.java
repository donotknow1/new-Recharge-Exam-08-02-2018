package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import bean.RechargeBean;
import util.DBUtil;

public class RecDao implements IRecDao {
Connection conn=null;
int status=0;
	@Override
	public int addDetails(RechargeBean b1) throws SQLException {
		// TODO Auto-generated method stub
		conn=DBUtil.getDbConnection();
		PreparedStatement pst = conn.prepareStatement(IQueryMapper.rec_insert_qry);
try {
	pst.setString(1, b1.getName());
pst.setString(2, b1.getNumber());
pst.setInt(3,b1.getAmount());
pst.setString(4, b1.getPlan());
status=pst.executeUpdate();
}
catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
		return status;
	}
	/*@Override
	public int addFianlDetails(RechargeBean b1) throws SQLException {
		// TODO Auto-generated method stub
		conn=DBUtil.getDbConnection();
		PreparedStatement pst = conn.prepareStatement(IQueryMapper.rec_insert_qry1);
try {
	pst.setString(1, b1.getName());
pst.setString(2, b1.getNumber());
pst.setInt(3,b1.getAmount());
pst.setString(4, b1.getPlan());
pst.setString(5,b1.getStatus());
status=pst.executeUpdate();
}
catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
		return status;*/
	
	}
