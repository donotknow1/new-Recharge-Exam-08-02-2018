package rec.service;

import rec.bean.RechargedemoBean;
import rec.exception.RechargedemoException;

public interface IRechargedemoService 
{
public int storerechargeid(RechargedemoBean rb) throws RechargedemoException;

	public int storeDetails(RechargedemoBean rb) throws RechargedemoException;
	
	public String validateamount(int amount);

}
