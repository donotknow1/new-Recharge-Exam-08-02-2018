package rec.bean;

public class RechargedemoBean 
{
	private int rechId;
	private String name;
	private String mobnum;
	private int Amount;
	private String planname;
	private String date;
	private String status;
	
	
	
	
	public int getRechId() {
		return rechId;
	}
	public void setRechId(int rechId) {
		this.rechId = rechId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobnum() {
		return mobnum;
	}
	public void setMobnum(String mobnum) {
		this.mobnum = mobnum;
	}
	public int getAmount() {
		return Amount;
	}
	public void setAmount(int amount) {
		Amount = amount;
	}
	public String getPlanname() {
		return planname;
	}
	public void setPlanname(String planname) {
		this.planname = planname;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
	
	public RechargedemoBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public RechargedemoBean(int rechId, String name, String mobnum, int amount, String planname, String date,
			String status) {
		super();
		this.rechId = rechId;
		this.name = name;
		this.mobnum = mobnum;
		Amount = amount;
		this.planname = planname;
		this.date = date;
		this.status = status;
	}
	public RechargedemoBean(String name, String mobnum, int amount, String planname, String status) {
		super();
		this.name = name;
		this.mobnum = mobnum;
		Amount = amount;
		this.planname = planname;
		this.status = status;
	}
	
	
	
	
	
	
	
	

}
